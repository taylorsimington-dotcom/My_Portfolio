## Clock
##

class Clock():
    def main(self, Hour, Min, Action):
        day = 1
        plusTime = self.timeAttrib(Action)
        Hour, Min = self.updateTime(Hour, Min, plusTime)
        check = self.checkDayEnd(Hour, Min)
        if check == True:
            self.updateCalendar()            
            
        return Hour, Min, day

    def timeAttrib(Action):
        if Action == "Move":
            output = 10
        elif Action == "Talk":
            print("action is talk")
            output = 4
        elif Action == "Eat":
            output = 22
        elif Action == "Bus":
            output = 35
        elif Action == "Activity":
            output = 95
        elif Action == "Cutscene":
            output = 45
        else:
            print("An error has occured in Clock under timeAttrib")
            
        return output
        
    def updateTime(Hour, Min, plusTime):
        plusHour = 0
        plusMin = 0
        if plusTime > 59:
            plusHour = plusTime // 60
            plusMin = plusTime % 60
            print("adding ", plusHour, " hours and ", plusMin, " minutes.")
            Hour += plusHour
            Min += plusMin
            print("Time: ", Hour, Min)
            if Min == 60:
                print("adding hour, zeroing minutes")
                Hour += 1
                Min = 0       
            elif Min >= 61:
                m = Min % 60
                h = Min // 60
                Hour += h
                Min = m
                print("Time: ", Hour, Min)

            else:
                print("An error has occured in Clock at updateTime")

        elif plusTime <= 59:
            Min += plusTime
            if Min == 60:
                print("adding hour, zeroing minutes")
                Hour += 1
                Min = 0       
            elif Min > 59:
                Hour += Min % 60
                Min = Min - Hour
            else:
                print("An error has occured in Clock at updateTime")
        
        return Hour, Min   
    
    def checkDayEnd(Hour, Min, day, calendar):
        status = False
        for i in sorted(calendar.keys()):
            if day == i:
                date = i
        time = str(Hour) + str(Min)
        if calendar[date] == time:
            status = True
            
        return status                 
    
    def calendar():
        calendar = {"June 1":2057, "June 2":2058, "June 3":2059, "June 4":2059, 
            "June 5":2100, "June 6":2101, "June 7":2102, "June 8":2102,
            "June 9":2103, "June 10":2104, "June 11":2104, "June 12":2105,
            "June 13":2105, "June 14":2106, "June 15":2106, "June 16":2107,
            "June 17":2107, "June 18":2107, "June 19":2108, "June 20":2108, 
            "June 21":2108, "June 22":2108, "June 23":2109, "June 24":2109,
            "June 25":2109, "June 26":2109, "June 27":2109, "June 28":2109,
            "June 29":2109, "June 30":2109}
        
        return calendar
        
    def updateCalendar(day, calendar):
        day += 1

        return day
                    







