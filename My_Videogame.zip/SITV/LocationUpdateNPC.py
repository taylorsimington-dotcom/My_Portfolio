## Location update NPC
## 

import random
from PlayerCollection import playerStats
from GameMapCollection import NPCroomUpdate

#                         Region           Address      Building     room
#location = {"Location":["North town", "109 6th street", "Diner", "Bathroom"]}
#schedule = {"7:30-8:00":["Direct","215 6th street, Bedroom", "Bus stop 4th street, None"], "8:00-15:30":["Archived"], "15:30-21:30":["Indirect","Bus stop 4th street, None","North town, South town"], "21:30-23:00":["Direct", "location", "215 6th street, Bedroom"], "23:00":["Asleep"]}
#time = 2130

class LocationUpdateNPC():   
    index = 0
    def main(self, schedule, location, time, fullName):
        check = self.updateCheck(time)
        
        if check == True:
            if schedule[time][0] == "Indirect":
                location = self.randomMove(self)
            elif schedule[time][0] == "Direct":
                destination = schedule[time][2]
                route = self.determineRoute(location, destination)
                moves = len(route)

                if self.index < moves:
                    moveto = route[self.index]
                    location = self.directMove(location, moveto)
                    self.index += 1

                if moves == self.index:
                    print("Char has reached destination.")

            else:
                pass

        #updateNPCcol()
        NPCroomUpdate(fullName, location)
        
        print(location)             
                         
    def updateCheck(self, time):
        check = False
        if time[2] == 0 or time[2] == 3:
            return check == True
            
    def determineRoute(location, destination):
        moves = 6 
        #call func wt graph & vertex
        
        return moves

    def randomMove(self, location):
        options = self.movementOptions()
        moveto = random.choice(options)
        self.directMove(self, location, moveto)
            
    def directMove(self, location, moveto):   
        location = playerStats()
        location["location"] == moveto   
        
        return location
            
    def movementOptions(location):
        # call upon index code
        pass    
    

 








 