## Game map
## 7/13/23
## 


def AreaCollection():
    Dict = {"North town":["108 & 106 4th street", "111 & 115 6th street", "103 6th street", "102 3rd street", "112 8th street", "109 6th street", "104, 105, & 106 6th street", "1 Warmgrove Rd","Bus stop"], "Neighborhood":["1091 & 93 6th street", "1092 & 94 6th street", "1095 & 97 6th street", "1096 & 98 6th street", '321 & 322 Greenriver Rd'], "South town":["406 8th street", "Cabin 1 8th street", "Cabin 2 Bybrook Ln", "Cabin 3 Dogwood Rd", "Cabin 4, 5, & 6 Dogwood Rd", "Cabin 7 Bybrook Ln", "Cabin 8 Bybrook Ln", "Cabin 9 Bybrook Ln", "408 Bybrook Park"], "East river":["East Bridge"], "West river":["West Bridge"], "Kennedy property":["Kennedy house", "Duffy house", "Amber's trailer"], "West exit to Highway 72":["7 Yellow Rd", "White ridge trail", "Harrow trail", "Hawkeye trail"], "East over the bridge":["3301 Cherry Ln", "Littlecreek trail", "Three Falls Drivein theater", "East Exit to I20"], "North past 4th street":["107 4th street","108 4th street", "109 4th street", "211 Willowood Ln"], "Far South woods":["Trail 1", "Trail 2", "Trail 3"], "Far North Trails":["Willowood Park", "Willowood Red Trail", "Willowood White Trail", "Willowood Black Trail"]}

    return Dict

def BuildingCollection():
    Dict = {"108 & 106 4th street":["Exploration Office", "Home Services"],"111 & 115 6th street":["Meredith's Bar", "Joshua's Diner"],"103 6th street":["Building 1"], "102 3rd street":["Building 2"], "112 8th street":["Building 3"], "109 6th street":["Building 4"], "104, 105, & 106 6th street":["Police station", "Building 5", "Building 6"], "1 Warmgrove Rd":["Church"],"Bus stop":["Bus stop"]}

    return Dict

def RoomCollection():
    Dict = {"Exploration office":["EPO - Main office"], "Home Services":["HSV - Workshop", "HSV - Back office", "HSV - Store room"], "Meredith's Bar":["MBR - Seating area", "MBR - Bar", "MBR - Bathroom"], "Joshua's Diner":["JSHD - Seating area", "JSHD - Register", "JSHD - Kitchen"], "Building 1":["B1 - Office"], "Building 2":["B2 - Office"], "Building 3":["B3 - Office"], "Building 4":["B4 - Office"], "Police station":["PCS - Main office", "PCS - Sherif's office", "PCS - Jail house"], "Building 5":["B5 - Office"], "Building 6":["B6 - Office"], "Church":["CHR - Sanctuary"], "Bus stop":["Bus stop"]}

    return Dict

def RoomNPCStatus():
    Dict = {"Bus Stop":["Dorian", "Sally", "Bill"]}
    
    return Dict

def NPCroomUpdate(fullName, location):
    Dict = RoomNPCStatus()
    Dict[location].append(fullName)
        