## Determine vis
import PlayerCollection

def determineVis(Status,Dict):
    if Status == "MM":
        location = "Kya-Falls"
    elif Status == "NG":
        location = "Bus-ride"
    elif Status == "ST":
        location = "Setting-img"
    elif Status == "MP":
        location = "Kya-Falls"
    elif Status == "IG":
        location = str(Dict["location"][1])
    else:
        print("An error has occured.")

    pic = location + ".png"

    return pic

