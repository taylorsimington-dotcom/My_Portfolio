## Player Collection
##

import json

def playerInfo():
    Dict = {"firstName":"???","lastName":"???","fullName":"???","age":0, "Gender":"???", "Birthday":"???", "relstatus":0, 
            "partner":"none", "occupation":"???", "address":"3301 Cherry Ln. Kya Falls MT", "Parents": True, "Parent Rel": "Neutral"}

    return Dict

def playerStats():
    Dict = {"Hunger":50, "Thirst":50, "Happiness":12, "Energy":30, "Bordom":50, "location":["None", "None"],"Money": 15.0}    

    return Dict

def playerInventory():
    Dict = {None:None}

    return Dict

def playerModif():
    Dict = {"E3":0, "E4":0, "E5":0, "Activities":[], "Food":[], "Hobbies":[], "Media":[], "Music":[], "Phobia":0, "Traits":[], "frYN":0, "MoreYN":0, "happyYN":0, "loveYN":0}

    return Dict

#___________________________________________________________________________________________________________

def newGameLoc():
    Dict = playerStats()
    loc = Dict["location"]
    loc.clear()
    loc.append("North town")
    loc.append("Bus-stop")
    
    return Dict

def enterName(name):
    Dict = playerInfo()
    Dict["fullName"] = name

    fn = name.split(" ")
    fsn = fn[0]
    lsn = fn[-1]

    Dict["firstName"] = fsn
    Dict["lastName"] = lsn

def enterAge(age):
    Dict = playerInfo()
    Dict["age"] = age 

def enterBirthday(bDay):
    Dict = playerInfo()
    Dict["Birthday"] = bDay

def enterGender(gender):
    Dict = playerInfo()
    Dict["Gender"] = gender

def locationUpdate(moveto):
    Dict = playerStats()        
    Dict["location"][1] = moveto   
    
    return Dict
    
def eat():
    pass

def drink():
    pass

def sleep():
    pass

def rest():
    pass
#_______________________________________________________________________________________________________
           

class SaveMyGame():
    # Opperates game save functions
    def defineNewCollection(self):
        # Collects the dicts from PlayerCollection
        infoDict = playerInfo()
        inventoryDict = playerInventory() 
        modifDict = playerModif()
        
        return infoDict, inventoryDict, modifDict

    def enterNewCollection(self, statusDict):
        # Enters the items from PlayerCollection into PlayerCol.txt
        infoDict, inventoryDict, modifDict = self.defineNewCollection()
        with open("PlayerCol.txt","w") as infile:
            contents = json.dumps(infoDict, indent=None) + "\n" + json.dumps(statusDict, indent=None) + "\n" + json.dumps(inventoryDict, indent=None) + "\n" + json.dumps(modifDict, indent=None)
            infile.write(contents)
            print("Game successfully saved.")

    def readGameSave(self):
        # Updates PlayerCollection to the items in PlayerCol.txt
         with open("PlayerCol.txt", "r") as infile:
            data = infile.readlines()

            if len(data) >= 4:
                player_info = json.loads(data[0])
                status_dict = json.loads(data[1])
                inventory_dict = json.loads(data[2])
                modif_dict = json.loads(data[3])
            else:
                print("Invalid data format in PlayerCol.txt.")
                return
            
            return player_info, status_dict, inventory_dict, modif_dict

    def clearGameSave(self):
        with open("PlayerCol.txt","w") as infile:
            infile.close() 


