## Character Movement Update
## 1/25/23
##

import PlayerCollection

class CharacterMovement():
    def getCurrentLoc(self, player_status):
        roomStatus = player_status["location"][1]

        return roomStatus

    def movementOptions(self, player_status):
        graphFile = "GameMap.txt"
        g = self.roomQueue(graphFile)
        roomStatus = self.getCurrentLoc(player_status)
        options = g.getNeighbors(roomStatus)
        
        return options
                      
    def roomQueue(self, graphFile):
        g = Graph()    
        gfile = open(graphFile,'r')
        for line in gfile:
            edgeInfo = line.strip().split()
            g.addEdge(edgeInfo[0],edgeInfo[1])
        
        return g

class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0
        
    def addVertex(self,key):
        self.numVertices = self.numVertices + 1
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        return newVertex
    
    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None

    def __contains__(self,n):
        return n in self.vertList
    
    def addEdge(self,f,t,cost=0):
        if f not in self.vertList:
            nv = self.addVertex(f)
        if t not in self.vertList:
            nv = self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t], cost)
    
    def getVertices(self):
        return self.vertList.keys()
        
    def __iter__(self):
        return iter(self.vertList.values())
    
    def getNeighbors(self, vertex_key):
        vertex = self.getVertex(vertex_key)
        if vertex is None:
            return []
        return [neighbor_vertex.getId() for neighbor_vertex in vertex.getConnections()]

class Vertex:
    def __init__(self,key, dist = 0, pred = None):
        self.id = key
        self.connectedTo = {}
        self.predecessor = pred
        self.distance = dist
        self.discovery = 0
        self.finish = 0

    def addNeighbor(self,nbr,weight=0):
        self.connectedTo[nbr] = weight

    def __str__(self):
        #return str(self.id) + ' connected To: ' + str([x.id for x in self.connectedTo])
        vals = str([x.id for x in self.connectedTo])
        
        return vals

    def getConnections(self):
        return self.connectedTo.keys()

    def getId(self):
        return self.id

    def getWeight(self,nbr):
        return self.connectedTo[nbr]

    def getPred(self):
        return self.predecessor

    def setPred(self, newPred):
        self.predecessor = newPred

    def getDiscovery(self):
        return self.discovery

    def setDiscovery(self, newDiscovery):
        self.discovery = newDiscovery

    def getFinish(self):
        return self.finish

    def setFinish(self, newFinish):
        self.finish = newFinish

    def getDistance(self):
        return self.distance

    def setDistance(self, newDistance):
        self.distance = newDistance












            

