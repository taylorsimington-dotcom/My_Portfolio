## Game GUI
## 7/13/23
## 

# imports
from tkinter import *
from tkinter.ttk import *
import tkinter as tk
from DetermineVis import determineVis
from PIL import Image, ImageTk
import PlayerCollection
import PlayerMovement
from GameMapCollection import RoomNPCStatus


class RunMainMenu():
    #Runs the Main Menu GUI
    def Menu(self):
        self.m = tk.Tk()
        self.m.title("Summer in The Valley - Main Menu")
        frame = tk.Frame(self.m)

        frame.pack(side= 'bottom')
        bottomFrame = tk.Frame(self.m)
        bottomFrame.pack(side= 'bottom')

        self.buttons(frame, self.m)

        img = self.visual()

        photo = tk.Label(self.m, image= img)
        photo.pack(side= "top")

        self.m.mainloop()

    def visual(self):
        Status = "MM"
        Dict = PlayerCollection.playerStats()
        vis = determineVis(Status, Dict)
        img = ImageTk.PhotoImage(Image.open(vis))

        return img

    def buttons(self, frame, m):
        tk.Label(frame, text="").pack(side="bottom")
        gameExit = tk.Button(frame, text= 'Exit Game', width= 25, fg="brown", command=self.m.destroy)
        gameExit.pack(side= "bottom")
        gameSettings = tk.Button(frame, text= 'Settings', width= 25, fg="brown", command=self.runSettings)
        gameSettings.pack(side= "bottom")
        newGame = tk.Button(frame, text= 'New Game', width= 25, fg="brown", command= self.startNewGame)
        newGame.pack(side= "bottom")
        returnGame = tk.Button(frame, text= 'Load Game', width= 25, fg="brown",
                               command=self.returnGame)
        returnGame.pack(side= "bottom")
        tk.Label(frame, text="").pack(side="bottom")


    def startNewGame(self):
        self.m.destroy()
        run = RunNewGame()
        run.start()

    def returnGame(self):
        Dict = PlayerCollection.SaveMyGame()
        Dict1, Dict2, Dict3, Dict4 = Dict.readGameSave()
        location = Dict2["location"][1]
        if location == "None":
            print("No previous save available.")
        else:
            new = False
            self.m.destroy()
            run = RunInGame()
            run.start(new)

    def runSettings(self):
        self.m.destroy()
        run = openSettings()
        run.settings()



class openSettings():
    def settings(self):
        self.m = tk.Tk()
        self.m.title("Summer in The Valley - Settings")
        self.m.geometry("600x550")
        frame = tk.Frame(self.m)

        frame.pack(side= 'right')
        bottomFrame = tk.Frame(self.m)
        bottomFrame.pack(side= 'right')

        img = self.visual()
        photo = tk.Label(self.m, image= img)
        photo.pack(side= "top")

        self.buttons(frame, self.m)

        self.m.mainloop()

    def visual(self):
        Status = "ST"
        Dict = PlayerCollection.playerStats()
        vis = determineVis(Status,Dict)
        img = ImageTk.PhotoImage(Image.open(vis))

        return img

    def buttons(self, frame, m):
        MenuReturn = tk.Button(frame, text= "Main Menu", width= 25, command= self.startMainMenu)
        MenuReturn.pack(side= "bottom")
        Audio = tk.Button(frame, text= 'Audio Options', width= 25)
        Audio.pack(side= "bottom")
        Gameplay = tk.Button(frame, text= 'Gameplay Options', width= 25)
        Gameplay.pack(side= "bottom")
        Options = tk.Button(frame, text= 'Other Options', width= 25)
        Options.pack(side= "bottom")

    def startMainMenu(self):
        self.m.destroy()
        run = RunMainMenu()
        run.Menu()



class RunNewGame():
    # Runs the New Game GUI
    def __init__(self):
        self.m = tk.Tk()
        self.m.title("Summer in The Valley - New Game")
        self.img = None  # Placeholder for ImageTk object

    def start(self):
        self.img = ImageTk.PhotoImage(Image.open("Bus-ride.png"))
        self.NewGameCheck()

        self.m.mainloop()

    def NewGameCheck(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0)
        
        tk.Label(self.m, text= "WARNING! Selecting 'Continue' bellow will PERMANENTLY delete your previous save.").grid(row=1)
        tk.Label(self.m, text= "Are you sure you want to continue?").grid(row=2)
        tk.Label(self.m, text= "").grid(row=4)
        tk.Button(self.m, text= 'Return to Main Menu', width= 25, fg="brown", command=self.startMainMenu).grid(row=5)
        tk.Label(self.m, text="").grid(row=6)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q1).grid(row=7)
        tk.Label(self.m, text="").grid(row=8)

    def Q1(self):
        save = PlayerCollection.SaveMyGame()
        save.clearGameSave()
        
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0)

        tk.Label(self.m, text= "Stranger: Hey, you. You're finally awake- Oh wait, wrong game-").grid(row=1)
        tk.Label(self.m, text= "Good morning sleepy head, how are you feeling? ..What? Who, me?").grid(row=2)
        tk.Label(self.m, text= "Oh, that's not important. I was more curious about you. What's your name?").grid(row=3)
        e1 = tk.Entry(self.m)
        e1.grid(row= 4)
        tk.Label(self.m, text= "").grid(row=5)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q2).grid(row=6)
        tk.Label(self.m, text= "").grid(row=7)


    def Q2(self):
        #PlayerCollection.enterName(name)
    
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        v = StringVar(self.m, "1")
        options = {"M": 1, "F": 2, "T": 3}

        row = 1
        for txt, val in options.items():
            e22 = Radiobutton(self.m, text=txt, variable=v, value=val)
            e22.grid(row=row, column=0, columnspan=3, padx=10, pady=5)
            row += 1   

        tk.Label(self.m, text="").grid(row=row, column=0, columnspan=3)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q3).grid(row=row + 1, column=0, columnspan=3)
        tk.Label(self.m, text="").grid(row=row + 2, column=0, columnspan=3)

    def Q3(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)
        
        fn = "Kent"
        fs = "Stranger: Hm. Ok, " + fn + ". Not sure I believe you but whatever. While we’re getting cozy, how old are you?"

        tk.Label(self.m, text= fs).grid(row=1)
        tk.Label(self.m, text= "I’m not gonna get put on a registry for talking to you right?").grid(row=2)
        e2 = tk.Entry(self.m)
        e2.grid(row=3)
        tk.Label(self.m, text="Birth month/day(ex:'June 2')").grid(row=4)
        e21 = tk.Entry(self.m)
        e21.grid(row=5)
        
        tk.Label(self.m, text="").grid(row=6)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q31).grid(row=7)
        tk.Label(self.m, text="").grid(row=8)

    def Q31(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)
        # age = int(e2.get())
        # PlayerCollection.enterAge(age)
        # bday = int(e21.get())
        # PlayerCollection.enterBirthday(bday)
        # PlayerCollection.enterGender(e22)
        # Dict = PlayerCollection.playerInfo()
        age = 27
        fn = "Kent"
        resp = ""
        if age == 17:
            resp = "Stranger: Hm. Ok, " + fn + ". Not sure I believe you but whatever. While we’re getting cozy, how old are you? I’m not gonna get put on a registry for talking to you right?"
        elif age >= 18 and age < 29:
            resp = "Stranger: Oh phew! But what’s someone with so much youth doing on a bus out into the big wide nowhere?"
        elif age >= 29 and age <=55:
            resp = "Stranger: Wow, you’re looking pretty good for " + str(age) + ". Do you moisturize? Have some work done? You know what- I really don’t care. Why are you on this bus?"
        elif age >= 56:
            resp = "Stranger: You know, I’ve been looking for a sugar daddy/mommy- Don’t look at me like that I’m kidding! I’m kidding. What brings you to this side of the valley?"
        else:
            print("an error has occured on Q3() of MyGameGUI")

        if age < 55:
            par1 = "I’m just here visiting my grandparents for the summer. I don’t know them very well so I won’t be staying long, probably a week or two." 
            par2 = "I’m visiting my grandparents. I used to do it every summer when I was a kid. Thought I would come back one more time. I kinda needed a break from where I was living."
            par3 = "I’m kinda looking to get away from the world. Maybe settle down there. The wild areas just… really speak to me."
            par4 = "I’m visiting some old friends. I’m not sure if they remember me- it was a long time ago- but I felt like I needed to come back."
            par5 = "It’s kind of personal business. Maybe you should just stay out of it."
        else:
            par1 = "I’m just here visiting my parents for the summer. I don’t know them very well so I won’t be staying long, probably a week or two." 
            par2 = "I’m visiting my parents. Thought I would come back one more time. I kinda needed a break from where I was living."        
            par3 = "I’m kinda looking to get away from the world. Maybe settle down there. The wild areas just… really speak to me."
            par4 = "I’m visiting some old friends. I’m not sure if they remember me- it was a long time ago- but I felt like I needed to come back."
            par5 = "It’s kind of personal business. Maybe you should just stay out of it."
        
        options = {par1 : 1,
                   par2 : 2,
                   par3 : 3,
                   par4 : 4,
                   par5 : 5
                   }
        v = StringVar(self.m, "1")
        tk.Label(self.m, text= resp).grid(row=1)

        row = 2
        for (txt, val) in options.items():
            e3 = Radiobutton(self.m, text=txt, variable=v, value=val)
            e3.grid(row=row)
            row += 1   

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q4).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q4(self):
        #Dict = PlayerCollection.playerInfo()
        #Dict["E3"] = e3
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "You have a family? How do you feel about them?").grid(row=1)

        v = StringVar(self.m, "1")
        options = {"Good" : 1,
                   "Neutral" : 2,
                   "Bad" : 3,
                   "I don't have a family.": 4
                   }        
        row = 2
        for (txt, val) in options.items():
            e4 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e4.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row, column=0, columnspan=3)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q5).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)


    def Q5(self):
        #Dict = PlayerCollection.playerInfo()
        #Dict["E4"] = e4
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "...So, what do you want to do with your life? Hm? Anything Interesting?").grid(row=1)
        
        v = StringVar(self.m, "1")
        options = {'Get rich. The whole “money doesn’t buy happiness" was made up by the rich to trick everyone else.' : 1,
                   "Make just enough money to enjoy my hobbies and live free. Nothing crazy, just be happy with myself and see what the future has in store. Something like that." : 2,
                   "Find someone to make it all worth it. I’m pretty comfortable with myself but things are always just a little bit more perfect when you have someone else to enjoy them with." : 3,
                   "Explore the world. Try new things. A lot of different stuff.": 4,
                   "I want to take care of people.": 5,
                   "I don't know. Does anyone really know?": 6,
                   "Life has kind of kicked my ass for a long time. There’s no way it can get any lower from here so… Just ready for things to get better.": 7
                   }        
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q6).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)


    def Q6(self):
        #Dict = PlayerCollection.playerInfo()
        #Dict["E5"] = e5
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Hobbies? Stuff you like and whatnot?").grid(row=1)
        tk.Label(self.m, text= "Pick 2 activities:").grid(row=2)
        
        v = {"Outdoor adventures":1, 
             "Going out to the movies":2,
             "Traveling":3,
             "Eating/trying new things":4,
             "Sports/Exercise":5,
             "Relaxing at home":6
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=3)

        tk.Label(self.m, text= "").grid(row=4)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q7).grid(row=5)
        tk.Label(self.m, text= "").grid(row=6)

    def Q7(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 5 foods:").grid(row=1)

        v = {"Jar of pickles":1,
             "PB&J":2,
             "BLT":3,
             "Twynkee":4,
             "Canned Sardines":5,
             "Ramen packet":6,
             "Pizza":7,
             "Fried Chicken":8,
             "Pineapple":9,
             "Hotdog":10,
             "Corn Dog":11,
             "Salad":12,
             "Pickle on a stick":13,
             "Tuna salad sandwich":14,
             "Popcorn":15,
             "Mozzarella sticks":16,
             "Peach":17,
             "Grapes":18,
             "Apples":19,
             "Steak 8oz":20,
             "Steak 16oz":21,
             "Steak 32oz":22,
             "Chinese takeout":23,
             "Banana":24,
             "Cheesecake":25,
             "Raspberry pie":26,
             "Funnnions":27,
             "Soup":28,
             "Mac n' cheese":29,
             "Bologna":30,
             "Meatloaf":31,
             "Hot pocket":32,
             "Shrimp on a stick":33,
             "Black berries":34,
             "Olives":35,
             "Cheese":36,
             "Cheese product  & Ritz crackers":37,
             "Sushi":38,
             "Keylime pie":39,
             "Pecan pie":40,
             "A Soggy Quesadilla":41,
             "Wood plank salmon and rice":42,
             "Chili and cinnamonrolls":43,
             "Braut with bun and chips":44,
             "Cuban sandwich":45,
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q8).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q8(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 3 Hobbies:").grid(row=1)
        
        v = {"Playing an instrument":1,
             "Playing a sport":2,
             "Some kind of art":3,
             "Reading and/or writing":4,
             "Cooking":5,
             "Attending my wednesday night church group":6,
             "Video games":7,
             "Meeting people":8,
             "Some kind of craft (crochet, wood working, etc.)":9,
             "Partying":10,
             "Being gay":11,
             "Gardening":12,
             "Collectables":13,
             "Witchcraft":14,
             "Summoning Satan":15,
             "Taking care of my animals":16,
             "Something that involves computers":17,
             "Something niche":18,
             "Idk I’m kinda boring.":19,
             "Doing your mom":20
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q9).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q9(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 2 genres of media:").grid(row=1)
        
        v = {"Comedy":1,
             "Romance":2,
             "Horror":3,
             "Fantasy":4,
             "Sci-fi":5,
             "Art-house":6,
             "Thriller":7,
             "Psychological":8,
             "Crime":9,
             "Western":10,
             "Historical":11,
             "Fiction":12,
             "Non-fiction":13
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q10).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q10(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 2 genres of music:").grid(row=1)
        
        v = {"Rock":1,
             "Pop":2,
             "Classical":3,
             "Hip-hop":4,
             "Metal":5,
             "Country":6,
             "Rap":7,
             "Alternative":8,
             "Folk":9,
             "Indie":10,
             "EDM":11,
             "Jazz":12,
             "Oldies":13,
             "Blues":14,
             "Grunge":15
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q11).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q11(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Which of these are you most afraid of?").grid(row=1)
        options = {"Arachnophobia: an intense fear of spiders and other arachnids":1,
                   "Ophidiophobia: an intense fear of snakes":2,
                   "Acrophobia: an intense fear of heights":3,
                   "Aerophobia: an intense fear of flying":4,
                   "Cynophobia: an intense fear of dogs":5,
                   "Astraphobia: an intense fear of thunder and lightning":6,
                   "Trypanophobia: an intense fear of injections":7,
                   "Social phobia: an intense fear of social interactions":8,
                   "Agoraphobia: an intense fear of places that are difficult to escape, sometimes involving fear of crowded or open spaces":9,
                   "Mysophobia: an intense fear of germs, dirt, and other contaminants":10,
                   "Autophobia: an intense fear of being alone":11
                   }
        
        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q12).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)


    def Q12(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 2 of these which best describe you:").grid(row=1)
        
        v = {"Kind":1,
             "Down to earth":2,
             "Peaceful":3,
             "Boisterous":4,
             "Quiet":5,
             "Anxious":6,
             "Tough skinned":7,
             "Tired":8,
             "Ambitious":9,
             "Generous":10,
             "Curious":11,
             "Creative":12,
             "Attentive":13
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q13).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q13(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Pick 2 of these which best describe you:").grid(row=1)
        
        v = {"Dramatic":1,
             "Petty":2,
             "Easily offended":3,
             "Pathetic":4,
             "Mean":5,
             "Envious/easily jealous":6,
             "Attention-seeking":7,
             "Apathetic":8,
             "Patronizing":9,
             "Angry":10
             }

        lb = Listbox(self.m)
        for (txt, val) in v.items():
            lb.insert(val, txt)
        lb.grid(row=2)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.Q14).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)

    def Q14(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Did you find the last question difficult to answer?").grid(row=1)
        
        options = {"Yes.":1,
             "No.":2,
             "I'm not sure.":3,
             "...":4
             }

        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q15).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q15(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Do you have many friends?").grid(row=1)
        
        options = {"Yes, they're very special to me.":1,
             "Yes, but they aren't very good people.":2,
             "No, but I wish I did.":3,
             "No, and I'm not interested in making them.":4,
             "I'm not sure.":5,
             "...":6
             }

        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q16).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q16(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Would you like to?/Would you like to have more?").grid(row=1)
        
        options = {"Yes. It's time for a change.":1,
             "Yes, but I'm not sure where to start.":2,
             "No, and I don't really want them.":3,
             "Kinda. I don't know.":4,
             "...":5
             }

        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q17).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q17(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Are you wondering when this suddenly turned into unprovoked therapy?").grid(row=1)
        
        options = {"...":1,
             "...":2,
             "...":3
             }

        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q18).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q18(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Are you happy?").grid(row=1)
        
        options = {"Yes.":1,
             "No.":2,
             "I'm not sure.":3,
             "...":4
             }
        
        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q19).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q19(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Have you ever been in love?").grid(row=1)
        
        v = {"Yes.":1,
             "No.":2,
             "I'm not sure.":3,
             "...":4
             }

        options = StringVar(self.m, "1")
        row = 2
        for (txt, val) in v.items():
            e5 = Radiobutton(self.m, text= txt, variable=options, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q20).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q20(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Are you even sure what that means?").grid(row=1)
        
        options = {"...":1,
             "...":2,
             "...":3
             }
        
        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Q21).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Q21(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Do you know how to say anything other than single word answers? No? Ok.").grid(row=1)
        
        options = {"...":1,
             "...":2,
             "...":3
             }

        v = StringVar(self.m, "1")
        row = 2
        for (txt, val) in options.items():
            e5 = Radiobutton(self.m, text= txt, variable=v, value=val)
            e5.grid(row=row)
            row += 1

        tk.Label(self.m, text="").grid(row=row)
        tk.Button(self.m, text='Continue', width=25, fg="brown", command=self.Closure).grid(row=row + 1)
        tk.Label(self.m, text="").grid(row=row + 2)

    def Closure(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=3)

        tk.Label(self.m, text= "").grid(row=0)
        tk.Label(self.m, text= "Maybe someday you'll find out. Looks like we're almost to the bus stop.").grid(row=1)

        tk.Label(self.m, text= "").grid(row=3)
        tk.Button(self.m, text= 'Continue', width= 25, fg="brown", command=self.executeGame).grid(row=4)
        tk.Label(self.m, text= "").grid(row=5)
        

    def executeGame(self):
        new = True
        self.m.destroy()
        run = RunInGame()
        run.start(new)
        
    def startMainMenu(self):
        self.m.destroy()
        run = RunMainMenu()
        run.Menu()



class RunInGame():
    def __init__(self):
        self.m = tk.Tk()
        self.Info = PlayerCollection.playerInfo()
        player = self.Info["firstName"]
        self.m.title("Summer in The Valley - " + player)
        self.Status = PlayerCollection.playerStats()
        self.img = None  # Placeholder for ImageTk object

    def start(self, new):
        Status = "IG"
        if new == True:
            self.Status = PlayerCollection.newGameLoc()
            Col = PlayerCollection.SaveMyGame()
            Col.enterNewCollection(self.Status)
        else:
            Col = PlayerCollection.SaveMyGame()
            player_info, status_dict, inventory_dict, modif_dict = Col.readGameSave()
            self.Status = status_dict
        
        CM = PlayerMovement.CharacterMovement()
        options = CM.movementOptions(self.Status)

        vis = determineVis(Status, self.Status)
        self.img = ImageTk.PhotoImage(Image.open(vis))
        self.buttons()

        self.m.mainloop()

    def buttons(self):
        for widget in self.m.winfo_children():
            widget.destroy()
            
        Status = "IG"
        vis = determineVis(Status, self.Status)
        self.img = ImageTk.PhotoImage(Image.open(vis))
        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=8)

        tk.Label(self.m, text="").grid(row=1, column=0)        
        tk.Button(self.m, text='Move', width=15, command=self.moveCharInit).grid(row=2, column=1)
        tk.Button(self.m, text='Speak with character', width=15, command=self.interactNPC).grid(row=2, column=2)
        tk.Button(self.m, text='Inventory', width=15, command=self.viewInventory).grid(row=2, column=3)
        tk.Button(self.m, text='View Map', width=15, command=self.viewMap).grid(row=2, column=4)
        tk.Button(self.m, text='Search', width=15, command=self.m.destroy).grid(row=2, column=5)
        
        tk.Label(self.m, text="").grid(row=2, column=6)        
        tk.Button(self.m, text='Save', width=18, command=self.initSaveGame).grid(row=2, column=7)
        tk.Button(self.m, text='Menu', width=18, command=self.startMainMenu).grid(row=3, column=7)
        tk.Label(self.m, text="").grid(row=5, column=0)      

    def moveCharInit(self):
        for widget in self.m.winfo_children():
            widget.destroy()
            
        Status = "IG"
        vis = determineVis(Status, self.Status)
        self.img = ImageTk.PhotoImage(Image.open(vis))
        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=7)

        self.options = PlayerMovement.CharacterMovement().movementOptions(self.Status)
        tk.Label(self.m, text="").grid(row=1, column=0)        
        column=2
        for each in self.options:
            tk.Button(self.m, text=each, width=15, command=lambda option=each: self.updateOnClick(option)).grid(row=2, column=column)            
            column +=1
        
        tk.Label(self.m, text="").grid(row=2, column=5)        
        tk.Button(self.m, text='Save', width=18, command=self.initSaveGame).grid(row=2, column=6)
        tk.Button(self.m, text='Return', width=18, command=self.buttons).grid(row=3, column=6)
        tk.Label(self.m, text="").grid(row=5, column=0)      

    def updateOnClick(self, each):
        self.Status = PlayerCollection.locationUpdate(each)  # Update player's location
        self.moveCharInit()      
        self.m.update_idletasks()
        
    def interactNPC(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=7)

        Dict1 = PlayerCollection.playerStats()
        location = Dict1["location"][1]
        Dict2 = RoomNPCStatus()
        npcList = Dict2[location]
        
        if len(npcList) == 0:
            tk.Label(self.m, text= "").grid(row=1)
            tk.Label(self.m, text= "There isn't anyone here to speak with.").grid(row=2)
            tk.Label(self.m, text= "").grid(row=3)
            tk.Button(self.m, text='Save', width=18, command=self.initSaveGame).grid(row=4, column=4)
            tk.Button(self.m, text='Return', width=18, command=self.buttons).grid(row=4, column=4)
            tk.Label(self.m, text="").grid(row=5, column=0)      
        else:                
            #tk.Label(self.m, text="").grid(row=1)      
            tk.Label(self.m, text="Select who you would like to speak with.").grid(row=1, column=2)      
            tk.Label(self.m, text="").grid(row=2)      
            
            row = 3
            for each in npcList:
                tk.Button(self.m, text=each, width=18, command=self.m.destroy).grid(row=row, column=2)
                row += 1            

            tk.Label(self.m, text="").grid(row=row+1)      
            tk.Button(self.m, text='Save', width=18, command=self.initSaveGame).grid(row=row-1, column=4)
            tk.Button(self.m, text='Return', width=18, command=self.buttons).grid(row=row-2, column=4)
    
    def viewInventory(self):
        for widget in self.m.winfo_children():
            widget.destroy()

        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=7)
        
        tk.Label(self.m, text="").grid(row=1)
        Dict = PlayerCollection.playerInventory()
        row = 2
        for key,val in Dict.items():
            tk.Label(self.m, text=key).grid(row=row, column=2)
            tk.Label(self.m, text=str(val)).grid(row=row, column=3)
            tk.Button(self.m, text="X", width=8, command=self.m.destroy).grid(row=row, column=4)
            row += 1
        
        tk.Label(self.m, text="").grid(row=row+1)      
        tk.Button(self.m, text='Return', width=18, command=self.buttons).grid(row=row+2, column=4)
        tk.Label(self.m, text="").grid(row=row+3)      
        
    def viewMap(self):
        for widget in self.m.winfo_children():
            widget.destroy()
        
        vis = "Graph-paper.png"
        self.img = ImageTk.PhotoImage(Image.open(vis))
        photo = tk.Label(self.m, image=self.img)
        photo.grid(row=0, column=0, columnspan=7)
        
        tk.Label(self.m, text="").grid(row=1, column=5)        
        tk.Button(self.m, text='Return', width=18, command=self.buttons).grid(row=2, column=4)
        tk.Label(self.m, text='', width=18).grid(row=3)
        
    def searchArea():
        pass
        
    def initSaveGame(self):
        save = PlayerCollection.SaveMyGame()
        save.enterNewCollection(self.Status)
    
    def startMainMenu(self):
        self.m.destroy()
        run = RunMainMenu()
        run.Menu()



class GameGUI():
    def main(self, Status):
        if Status == "MM":
            run = RunMainMenu()
            run.Menu()
        elif Status == "NG":
            run = RunNewGame()
            run.NewGame()
        elif Status == "IG":
            new = False
            run = RunInGame()
            run.start(new)
        else:
            print("An error has occured in 'MyGameGUI.py'.")


Status = "MM"
myGame = GameGUI()
myGame.main(Status)







