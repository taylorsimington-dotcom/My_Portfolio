## item list
## 4/11/23
## 

import csv

def food(foodID):
    if len(itemData) > 0:
        itemData = []
    itemData = []
    with open("foodFile.csv", "r") as myfile:
        reader = csv.readline(myfile)
        for each in reader:
            if each[0] == foodID:
                for i in each:
                    itemData.append(i)
            else:
                continue

    return itemData

def wearableItems():
    Dict = {}

    return Dict

def valuables():
    Dict = {}

    return Dict

def nicknacks():
    Dict = {}

    return Dict    

def storyItems():
    Dict = {}

    return Dict










































