## Dynamic scraping tool
## 2/22/23-5/10/23 Taylor Simington
## Attempt 1
## This project is a scraping tool that will take a given hyperlink, identify 
## requested data, and return that data to the user in an excel spread sheet 
## format. 
##

# Imports
import os
import random
import time
import csv
import requests
import re
from bs4 import BeautifulSoup


def main():
    print("Welcome to Taylor's scraping tool! You have some options now that you're here.")
    print("First, you may simply chose to collect data from one specific page.")
    print("Second, you can collect the data from every item linked in a search.")
    print("Enter 1 for the first option, enter 2 for the second option, and enter I for a more detailed description on what this means.")
    print("Or enter E to exit the program.")
    status = True
    while status == True:
        fails = 0
        searchCheck = input("Enter your selection here: ")
        if searchCheck == "1":
            myURL, tags, keyWords, FileName, keyQ = UserInputs()
            FileName = fileNameCheck(FileName)
            HEADERS = Bypass()
            link = collectHTML(myURL,HEADERS)
            dataOutput = readHTML(link, tags, keyWords, keyQ)
            #print(dataOutput)
            ToCSV(dataOutput, FileName)    
       
        elif searchCheck == "2":        
            myURL, tags, keyWords, FileName, keyQ = UserInputs()
            FileName = fileNameCheck(FileName)
            HEADERS = Bypass()
            link = collectHTML(myURL,HEADERS)
            worksList = getSubLinks(link)
            for each in worksList:
                link = collectHTML(each,HEADERS)
                dataOutput = readHTML(link, tags, keyWords, keyQ)
                ToCSV(dataOutput, FileName)     
                
        elif searchCheck == "I":
            print("Selecting option 2 will allow you to paste the link of a search engine and collect data from each result")
            print("For example, you could go to Walmart.com and search an item of your choice into the search bar.")
            print("You can use the resulting hyperlink of this search to collect data from all results of this search.")
            print("If you still don't understand what this means email me ig. --> simingtt@uni.edu")
            
        elif searchCheck == "E":
            print("Wow, you're leaving already? Getting off that data grind? Bye, I guess.")
            print("Program successfully closed.")
            break
            
        else:
            fails += 1
            print("Whatever you entered wasn't an option. If it was a mistake, it's okay, you can try as many times as you want.")
            print("...If it wasn't a mistake you either need to go back to preschool or you're testing my program.")            
        
        if fails == 10:
            print("Actually, you know what... you've had 10 tries to make this work and you're still riding the struggle bus. Go do something else.")
            time.sleep(10)
            print("...")
            time.sleep(10)
            print("I'm serious, dog. I'm revoking your data-collecting priviledges. Come back in a few days and try again.")
            print("Program successfully closed.")
            break

def UserInputs():
    print("Hit UserInputs.")
    #myURL = input("Paste the hyperlink/s you would like to collect data from here: ")
    myURL = "https://www.newegg.com/g-skill-32gb/p/N82E16820374457?Item=N82E16820374457&cm_sp=Homepage_SS-_-P0_20-374-457-_-05102023"
    print("some options include: head, title, body, etc.")
    tagEntry = str(input("Enter the HTML tag you would like to collect here, seperated by commas: "))
    tags = list(tagEntry.split(','))
    FileName = str(input("Enter what you would like your tags csv file to be called: "))
    keyQ = input("Would you like to search for keywords? Y/N: ")
    if keyQ == "Y":
        keyEntry = input("Enter any key words you would like to search for here, seperated by commas: ")
        keyWords = list(keyEntry.split(','))
    elif keyQ == "N":
        keyWords = "None"
    else:
        print("please only write Y or N. Do not write yes or no.")
        
    return myURL, tags, keyWords, FileName, keyQ

def fileNameCheck(FileName):
    # check for files under the same name that already exist.
    print("Hit fileNameCheck.")
    FileName = FileName + ".csv"
    myDir = os.getcwd()
    if FileName in myDir:
        cont = input("The name you entered for your csv tags file already exists. Are you sure you would like to rewrite this file? Y/N: ")
        if cont == "Y":
            return FileName
        elif cont == "N":
            FileName = input("What would you like to rename your file?: ")
            return FileName
    else:
        with open(FileName, "x") as outfile:
            titles = ['item','element','type']
            writeFile = csv.writer(outfile)
            writeFile.writerow(titles)

        return FileName

def Bypass():
    print("Hit Bypass.")
    # Uses a User-Agent string to avoid these bot detection.
    # https://www.scrapingbee.com/blog/web-scraping-amazon/
    HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
                   'AppleWebKit/537.36 (KHTML, like Gecko)' 
                   'Chrome/112.0.0.0 Safari/537.36'),
    'Accept-Language': 'en-US, en;q=0.5'
    }

    return HEADERS
    
def collectHTML(myURL, HEADERS):
    # collects HTML. Waits for a random time for if the user
    # enters multiple hyperlinks to avoid overloading requests and getting
    # banned to the shadow realm.
    print("Hit ToHTML")
    wait = random.randint(1,20) #increase 2 to 20 once finished
    time.sleep(wait)
    link = requests.get(myURL) #headers = HEADERS
    link = link.text
    
    return link

def getSubLinks(link):
    # if initial link is a search, collects links of supplied options and scrapes from options.
    myText = BeautifulSoup(link, "html.parser")
    worksList = []
    for each in myText.find_all("a", href = True)[2:44]:
        item = each["href"]
        worksList.append(item)
        
    return worksList

def readHTML(link, tags, keyWords, keyQ):
    # reads the html files created in ToHTML and collects tags/keys
    print("Hit readHTML.")
    if keyQ == "Y":
        dataOutput = []
        myText = BeautifulSoup(link, "html.parser")
        print(tags)
        print(keyWords)
        for eachTag in tags:
            found = myText.find_all(eachTag)
            for file in found:
                print("found: ", file.string)
                file2 = str(file.string)
                stripped = str(re.sub('<.*?>', '', file2))
                item = list((stripped,str(eachTag),'tag'))
                dataOutput.append(item)
        for eachKey in keyWords:
            found2 = myText.find_all(text= eachKey)
            for file2 in found2:
                print("found: ", file2.string)
                file2 = str(file.string)
                stripped = str(re.sub('<.*?>', '', file2))
                item = list((stripped,str(eachKey),'keyword'))
                dataOutput.append(item)
        
        print(dataOutput)
        return dataOutput
    
    if keyQ == "N":
        dataOutput = []
        myText = BeautifulSoup(link, "html.parser")
        for eachTag in tags:
            found = myText.find_all(eachTag)
            for file in found:
                file2 = str(file.string)
                stripped = str(re.sub('<.*?>', '', file2))
                item = list((stripped,str(eachTag),'tag'))
                dataOutput.append(item)
        
        return dataOutput


def ToCSV(dataOutput, FileName):
    # Sends the data from readHTML to a csv file.
    print("Hit ToCSV.")
    with open(FileName, "w") as outfile:
        titles = ['item','element','type']
        writeFile = csv.writer(outfile)
        writeFile.writerow(titles)
        for each in dataOutput:
            writeFile.writerow(each)                

main()







